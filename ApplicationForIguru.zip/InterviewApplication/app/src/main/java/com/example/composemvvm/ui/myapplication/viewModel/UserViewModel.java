package com.example.composemvvm.ui.myapplication.viewModel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.composemvvm.ui.myapplication.model.User;
import com.example.composemvvm.ui.myapplication.model.UserRepository;
import com.example.composemvvm.ui.myapplication.model.UserResponse;
import com.example.composemvvm.ui.myapplication.repositary.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.List;

public class UserViewModel extends AndroidViewModel {
    private UserRepository repository;
    private LiveData<List<User>> allUsers;

    public UserViewModel(Application application) {
        super(application);
        repository = new UserRepository(application);
        allUsers = repository.getAllUsers();
    }

    public void fetchUsers() {
        RetrofitClient.getInstance().getApiService().getUsers(2).enqueue(new Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    repository.insertUsers(response.body().getData());
                }
            }

            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                // Handle the error
            }
        });
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }
}
