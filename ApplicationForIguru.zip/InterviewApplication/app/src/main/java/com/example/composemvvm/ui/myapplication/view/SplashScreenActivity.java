package com.example.composemvvm.ui.myapplication.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.composemvvm.ui.myapplication.R;

public class SplashScreenActivity  extends AppCompatActivity {

    private static final int SPLASH_SCREEN_TIMEOUT = 5000; // 5 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        // Create a new Handler to delay the transition to MainActivity
        new Handler().postDelayed(() -> {
            // Start MainActivity
            Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
            startActivity(intent);
            // Finish SplashScreenActivity so that the user can't go back to it
            finish();
        }, SPLASH_SCREEN_TIMEOUT);
    }
}