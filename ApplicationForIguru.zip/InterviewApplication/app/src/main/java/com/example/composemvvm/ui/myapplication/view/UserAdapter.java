package com.example.composemvvm.ui.myapplication.view;


import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.composemvvm.ui.myapplication.R;
import com.example.composemvvm.ui.myapplication.model.User;

public class UserAdapter extends ListAdapter<User, UserAdapter.UserHolder> {

    private static final DiffUtil.ItemCallback<User> DIFF_CALLBACK = new DiffUtil.ItemCallback<User>() {
        @Override
        public boolean areItemsTheSame(@NonNull User oldItem, @NonNull User newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull User oldItem, @NonNull User newItem) {
            return oldItem.getEmail().equals(newItem.getEmail());
        }
    };

    public UserAdapter() {
        super(DIFF_CALLBACK);
    }

    @NonNull
    @Override
    public UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_item, parent, false);
        return new UserHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull UserHolder holder, int position) {
        User currentUser = getItem(position);
        holder.bind(currentUser);
    }

    class UserHolder extends RecyclerView.ViewHolder {
        private ImageView imageViewAvatar;
        private TextView textViewName;
        private TextView textViewEmail;
        private ImageView imageViewUploadIcon;

        public UserHolder(View itemView) {
            super(itemView);
            imageViewAvatar = itemView.findViewById(R.id.image_view_avatar);
            textViewName = itemView.findViewById(R.id.text_view_name);
            textViewEmail = itemView.findViewById(R.id.text_view_email);
            imageViewUploadIcon = itemView.findViewById(R.id.image_view_upload_icon);
        }

        // Inside the bind method
        public void bind(User user) {
            textViewName.setText(user.getFirst_name() + " " + user.getLast_name());
            textViewEmail.setText(user.getEmail());

            // Load user avatar using Glide
            Glide.with(itemView.getContext())
                    .load(user.getAvatar())
                    .placeholder(R.drawable.baseline_360_24) // Placeholder image
                    .into(imageViewAvatar);

            // Add a click listener on the upload icon
            imageViewUploadIcon.setOnClickListener(v -> {
                // Create an Intent to start NextActivity
                Intent intent = new Intent(itemView.getContext(), LocationDetailsActivity.class);

                // Optionally, pass user data to the new activity
                intent.putExtra("user_first_name", user.getFirst_name());
                intent.putExtra("user_last_name", user.getLast_name());
                intent.putExtra("user_email", user.getEmail());
                intent.putExtra("user_avatar", user.getAvatar());

                // Start the new activity
                itemView.getContext().startActivity(intent);
            });
        }

    }
}
