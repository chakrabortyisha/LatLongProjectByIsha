package com.example.composemvvm.ui.myapplication.model;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class UserRepository {
    private UserDao userDao;
    private LiveData<List<User>> allUsers;

    public UserRepository(Application application) {
        UserDatabase database = UserDatabase.getInstance(application);
        userDao = database.userDao();
        allUsers = userDao.getAllUsers();
    }

    public void insertUsers(List<User> users) {
        new InsertUsersAsyncTask(userDao).execute(users);
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    private static class InsertUsersAsyncTask extends AsyncTask<List<User>, Void, Void> {
        private UserDao userDao;

        private InsertUsersAsyncTask(UserDao userDao) {
            this.userDao = userDao;
        }

        @Override
        protected Void doInBackground(List<User>... lists) {
            userDao.insertUsers(lists[0]);
            return null;
        }
    }
}
