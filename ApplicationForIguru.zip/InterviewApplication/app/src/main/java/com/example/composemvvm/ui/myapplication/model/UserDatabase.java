package com.example.composemvvm.ui.myapplication.model;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.annotation.NonNull;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.room.migration.Migration;

// Define the UserDatabase class
@Database(entities = {User.class}, version = 2, exportSchema = false) // Incremented version number
public abstract class UserDatabase extends RoomDatabase {
    private static volatile UserDatabase instance;

    // Define an abstract method for UserDao
    public abstract UserDao userDao();

    // Singleton pattern to get the instance of UserDatabase
    public static UserDatabase getInstance(final Context context) {
        if (instance == null) {
            synchronized (UserDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                                    UserDatabase.class, "user_database")
                            .addMigrations(MIGRATION_1_2) // Add migrations here
                            .build();
                }
            }
        }
        return instance;
    }

    // Optional: define a RoomDatabase.Callback to handle database creation events
    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            // You can perform additional operations here if needed when the database is created
        }
    };

    // Define migrations
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Implement migration logic here
            // For example, if you are adding a new column:
            database.execSQL("ALTER TABLE user ADD COLUMN new_column_name INTEGER DEFAULT 0 NOT NULL");
        }
    };
}
